//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.util.Arrays;
import static java.lang.System.*;

public class Lab15a
{
	public static void main(String args[])
	{
		//add test cases
		
		
		
				
	}
}