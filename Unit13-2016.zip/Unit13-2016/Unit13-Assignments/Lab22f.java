//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class - 
//Lab  - 

public class Lab22f
{
	public static void main(String args[])
	{
		QuickSort.quickSort(new Comparable[]{9,5,3,2});


		QuickSort.quickSort(new Comparable[]{19,52,3,2,7,21});


		QuickSort.quickSort(new Comparable[]{68,66,11,2,42,31});
	}
}


