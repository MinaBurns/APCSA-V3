//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class - 
//Lab  - 

import java.util.ArrayList;
import java.util.Collections;
import static java.lang.System.*;

class InsertionSort
{
	private ArrayList<String> list;

	public InsertionSort()
	{



	}

	//modfiers
	public void add( String  word)
	{
		int loc = 0;








	}


	public void remove(String word)
	{






	}

	public String toString()
	{
		return "";
	}
}