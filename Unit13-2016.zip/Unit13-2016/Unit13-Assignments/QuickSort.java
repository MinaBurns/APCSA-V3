//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class - 
//Lab  - 

import static java.lang.System.*;
import java.util.Arrays;		//use Arrays.toString() to help print out the array

public class QuickSort
{
	private static int passCount;

	public static void quickSort(Comparable[] list)
	{




	}


	private static void quickSort(Comparable[] list, int low, int high)
	{







	}


	private static int partition(Comparable[] list, int low, int high)
	{














		return 0;
	}
}