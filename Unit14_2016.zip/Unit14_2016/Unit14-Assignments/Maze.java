//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import static java.lang.System.*;

public class Maze
{
   private int[][] maze;

	public Maze()
	{


	}

	public Maze(int size, String line)
	{


	}

	public boolean hasExitPath(int r, int c)
	{

		return false;
	}

	public String toString()
	{
		String output="";





		return output;
	}
}