//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class - 
//Lab  -

import java.util.Scanner;
import static java.lang.System.*;

public class FancyWordTwo
{
	private char[][] mat;

	public FancyWordTwo()
	{

	}

   public FancyWordTwo(String s)
	{




	}

	public String toString()
	{
		String output="";





		return output+"\n\n";
	}
}